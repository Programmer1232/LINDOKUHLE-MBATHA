/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author lab_services_student
 */
public class Estate2 {
    
public class Main {
    public static void main(String[] args) {
        // Using a Two-dimensional array to store property sales for two of the estate agents
        double[][] propertySales = {
                {800000, 1500000, 2000000}, // Joe Bloggs
                {700000, 1200000, 1600000}  // Jane Doe
        };

        // Create an instance of EstateAgent
        EstateAgent estateAgent = new EstateAgent();

        // Display property sales for each estate agent.
        System.out.println("ESTATE AGENTS\tJAN\tFEB\tMAR");
        for (int i = 0; i < propertySales.length; i++) {
            System.out.print((i == 0 ? "Joe Bloggs\t" : "Jane Doe\t"));
            for (int j = 0; j < propertySales[i].length; j++) {
                System.out.print("R " + propertySales[i][j] + "\t");
            }
            System.out.println();
        }

        // Calculating  and displaying  total property sales for each estate agent.
        System.out.println("\nTotal Property Sales:");
        for (int i = 0; i < propertySales.length; i++) {
            double totalSales = estateAgent.EstateAgentSales(propertySales[i]);
            System.out.println((i == 0 ? "Joe Bloggs: " : "Jane Doe: ") + "R " + totalSales);
        }

        // Calculating and displaying the total 2% commission earned by each estate agent
        System.out.println("\nTotal 2% Commission Earned:");
        for (int i = 0; i < propertySales.length; i++) {
            double commission = estateAgent.EstateAgentCommission(propertySales[i]);
            System.out.println((i == 0 ? "Joe Bloggs: " : "Jane Doe: ") + "R " + commission);
        }

        // Display the top-selling estate agent
        int topAgentIndex = estateAgent.TopEstateAgent(propertySales);
        System.out.println("\nTop-preforming estate Agent: " + (topAgentIndex == 0 ? "Joe Bloggs" : "Jane Doe"));
    }
}





    
}
