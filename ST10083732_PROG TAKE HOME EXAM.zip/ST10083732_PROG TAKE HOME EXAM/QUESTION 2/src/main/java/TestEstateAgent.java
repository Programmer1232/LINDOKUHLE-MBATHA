

public class TestEstateAgent {

   
    public void testEstateAgentSales() {
        EstateAgent estateAgent = new EstateAgent();
        double[] propertySales = {800000, 1500000, 2000000};
        double totalSales = estateAgent.EstateAgentSales(propertySales);
        assertEquals(4300000, totalSales);
    }

    
    public void testEstateAgentCommission() {
        EstateAgent estateAgent = new EstateAgent();
        double[] propertySales = {800000, 1500000, 2000000};
        double commission = estateAgent.EstateAgentCommission(propertySales);
        assertEquals(86000, commission);
    }

  
    public void testTopEstateAgent() {
        EstateAgent estateAgent = new EstateAgent();
        double[][] totalSales = {
                {800000, 1500000, 2000000}, // Joe Bloggs
                {700000, 1200000, 1600000}  // Jane Doe
        };
        int topAgentIndex = estateAgent.TopEstateAgent(totalSales);
        assertEquals(0, topAgentIndex);
    }

    private void assertEquals(int i, double totalSales) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
