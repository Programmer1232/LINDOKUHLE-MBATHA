public class EstateAgent implements IEstateAgent {
    public double EstateAgentSales(double[] propertySales) {
        // Calculate total property sales for an estate agent
        double totalSales = 0;
        for (double sale : propertySales) {
            totalSales += sale;
        }
        return totalSales;
    }

    public double EstateAgentCommission(double[] propertySales) {
        // Calculate 2% commission for an estate agent
        double totalSales = EstateAgentSales(propertySales);
        return 0.02 * totalSales;
    }

    public int TopEstateAgent(double[][] totalSales) {
        // Find the index of the top-selling estate agent
        double maxSales = 0;
        int topAgentIndex = 0;
        for (int i = 0; i < totalSales.length; i++) {
            double agentSales = EstateAgentSales(totalSales[i]);
            if (agentSales > maxSales) {
                maxSales = agentSales;
                topAgentIndex = i;
            }
        }
        return topAgentIndex;
    }

    
   
}
