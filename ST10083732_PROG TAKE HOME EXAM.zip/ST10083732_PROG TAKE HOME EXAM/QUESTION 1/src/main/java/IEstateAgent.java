//IEstate App interface
public interface IEstateAgent {
    double CalculateCommission(double propertyPrice, double agentCommission);
    boolean ValidateData(String location, String agentName, String propertyPrice, String commissionPercentage);
}
