
public class EstateAgentTest {

   
    public void CalculateCommission_CalculatedSuccessfully() {
        EstateAgent estateAgent = new EstateAgent();
        double commission = estateAgent.CalculateCommission(100000, 5);
        assertEquals(5000, commission, 0.01);
    }

  
    public void CalculateCommission_CalculatedUnsuccessfully() {
        EstateAgent estateAgent = new EstateAgent();
        double commission = estateAgent.CalculateCommission(100000, 5);
        assertNotEquals(6000, commission, 0.01);
    }

  
    public void ValidationTest() {
        EstateAgent estateAgent = new EstateAgent();
        assertTrue(estateAgent.ValidateData("Cape Town", "John Doe", "200000", "2"));
        assertFalse(estateAgent.ValidateData("", "John Doe", "200000", "2"));
        assertFalse(estateAgent.ValidateData("Cape Town", "", "200000", "2"));
        assertFalse(estateAgent.ValidateData("Cape Town", "John Doe", "0", "2"));
        assertFalse(estateAgent.ValidateData("Cape Town", "John Doe", "200000", "0"));
    }

    private void assertEquals(int par, double par1, double par3) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


    private void assertTrue(boolean ValidateData) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertFalse(boolean ValidateData) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private void assertNotEquals(int i, double commission, double d) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
