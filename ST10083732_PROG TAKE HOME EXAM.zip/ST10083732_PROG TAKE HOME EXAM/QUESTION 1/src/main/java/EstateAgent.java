public class EstateAgent implements IEstateAgent {
    @Override
    //Calculating the commission for the estate agents
    public double CalculateCommission(double propertyPrice, double agentCommission) {
        return propertyPrice * (agentCommission / 100.0);
    }

    @Override
    //Validating the Data
    public boolean ValidateData(String location, String agentName, String propertyPrice, String commissionPercentage) {
        // Validation rules
        return !location.isEmpty()
                && !agentName.isEmpty()
                && isNumeric(propertyPrice) && Double.parseDouble(propertyPrice) > 0
                && isNumeric(commissionPercentage) && Double.parseDouble(commissionPercentage) > 0;
    }

    private boolean isNumeric(String str) {
        try {
            Double.valueOf(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
