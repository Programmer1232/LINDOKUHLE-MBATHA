import javax.swing.*;
import java.awt.event.ActionEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class EstateAgentApp extends JFrame {
    private final JComboBox<String> locationComboBox;
    private final JTextField agentNameTextField;
    private final JTextField propertyPriceTextField;
    private final JTextField commissionTextField;
    private final JTextArea reportTextArea;
    private final IEstateAgent estateAgent;
    private int columns;

    public EstateAgentApp() {
        setTitle("Estate Agent Commission Calculator");
        setSize(500, 400); 
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Initialize components
        locationComboBox = new JComboBox<>(new String[]{"Cape Town", "Durban", "Pretoria"});
        agentNameTextField = new JTextField();
        propertyPriceTextField = new JTextField();
        commissionTextField = new JTextField();
        reportTextArea = new JTextArea();
        reportTextArea.setEditable(false);
        estateAgent = new EstateAgent();

        // Create menu bar
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        // Create File menu
        JMenu fileMenu = new JMenu("File");
        menuBar.add(fileMenu);

        JMenuItem exitMenuItem = new JMenuItem("Exit");
        exitMenuItem.addActionListener((ActionEvent e) -> {
            System.exit(0);
        });
        fileMenu.add(exitMenuItem);

        // Create Tools menu
        JMenu toolsMenu = new JMenu("Tools");
        menuBar.add(toolsMenu);

        JMenuItem processReportMenuItem = new JMenuItem("Process Report");
        processReportMenuItem.addActionListener((ActionEvent e) -> {
            processReport();
        });
        toolsMenu.add(processReportMenuItem);

        JMenuItem clearMenuItem = new JMenuItem("Clear");
        clearMenuItem.addActionListener((ActionEvent e) -> {
            clearFields();
        });
        toolsMenu.add(clearMenuItem);

        JMenuItem saveReportMenuItem = new JMenuItem("Save Report");
        saveReportMenuItem.addActionListener((ActionEvent e) -> {
            saveReport();
        });
        toolsMenu.add(saveReportMenuItem);

        // Layout components using a layout manager (BoxLayout)
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        add(createLabeledPanel("AGENT LOCATION:", locationComboBox));
        add(createLabeledPanel("ESTATE AGENT NAME:", agentNameTextField)); // Increased width
        add(createLabeledPanel("PROPERTY PRICE:", propertyPriceTextField)); // Increased width
        add(createLabeledPanel("COMMISSION PERCENTAGE:", commissionTextField)); // Increased width
        add(createLabeledPanel("ESTATE AGENT REPORT:", new JScrollPane(reportTextArea))); // Increased width

        setVisible(true);
    }

    private JPanel createLabeledPanel(String label, JComponent component) {
        JPanel panel = new JPanel();
        panel.add(new JLabel(label));
        if (component instanceof JTextField jTextField) {
            jTextField.setColumns(columns);
        }
        panel.add(component);
        return panel;
    }

    private void processReport() {
        String location = (String) locationComboBox.getSelectedItem();
        String agentName = agentNameTextField.getText();
        String propertyPriceText = propertyPriceTextField.getText();
        String commissionPercentageText = commissionTextField.getText();

        if (estateAgent.ValidateData(location, agentName, propertyPriceText, commissionPercentageText)) {
            double propertyPrice = Double.parseDouble(propertyPriceText);
            double commissionPercentage = Double.parseDouble(commissionPercentageText);

            double commission = estateAgent.CalculateCommission(propertyPrice, commissionPercentage);

            // Display the detailed report in the text area
            reportTextArea.setText("AGENT LOCATION: " + location +
                    "\nESTATE AGENT NAME: " + agentName +
                    "\nPROPERTY PRICE: $" + propertyPrice +
                    "\nCOMMISSION PERCENTAGE: " + commissionPercentage + "%" +
                    "\nCOMMISSION EARNED: $" + commission);
        } else {
            JOptionPane.showMessageDialog(this, "Invalid data. Please check your input.");
        }
    }

    private void clearFields() {
        locationComboBox.setSelectedIndex(0);
        agentNameTextField.setText("");
        propertyPriceTextField.setText("");
        commissionTextField.setText("");
        reportTextArea.setText("");
    }

    private void saveReport() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("report.txt"))) {
            writer.write(reportTextArea.getText());
            JOptionPane.showMessageDialog(this, "Report saved successfully.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving report: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new EstateAgentApp();
        });
    }
}
